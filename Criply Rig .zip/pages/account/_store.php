
 <?PHP include("inc/_user_menu.php"); ?> 
<style>
.headerbar .top ul li a {
    font-size: 15px;
    color: #ffffff;
    font-weight: 700;
    padding: 5px 18px;
    border-radius: 1e3px;
    text-transform: uppercase;
}
.headerbar .top {
    /* height: 156px; */
    /* background: url(../images/top.png) no-repeat center top; */
    height: 100px;
    background: rgba(0,0,0,.5);
color: #fff;} 
.headerbar {
    height: 101px;
    background: url(../images/headers.png) no-repeat center top;
    position: relative;
    z-index: 99;
}
.footer-1 {
    padding: 40px 0;
    color: 00;
    background: #d8d1d585;
    margin-top: 181px;
}
.col-md-7 {
    display: inline-block;
    vertical-align: top;
    color: #fff;
    padding: 10px;
    width: 61%;
    margin-left: 538px;
}
.button:hover {
    color: #fff;
    text-transform: uppercase;
    background: #83b945;
    padding: 8px 12px;
    margin: 10px auto;
    display: table;
}
</style>
 


<div class="col-md-7">
						


			
<h3>My Wallet</h3>
<center>
<?PHP
$_OPTIMIZATION["title"] = "������� - ����/������� ������";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

	if(isset($_POST["sbor"])){
	
		if($user_data["last_sbor"] < (time() - 600) ){
		
			$tomat_s = $func->SumCalc($sonfig_site["a_in_h"], $user_data["a_t"], $user_data["last_sbor"]);
			$straw_s = $func->SumCalc($sonfig_site["b_in_h"], $user_data["b_t"], $user_data["last_sbor"]);
			$pump_s = $func->SumCalc($sonfig_site["c_in_h"], $user_data["c_t"], $user_data["last_sbor"]);
			$peas_s = $func->SumCalc($sonfig_site["d_in_h"], $user_data["d_t"], $user_data["last_sbor"]);
			$pean_s = $func->SumCalc($sonfig_site["e_in_h"], $user_data["e_t"], $user_data["last_sbor"]);
			$snow_s = $func->SumCalc($sonfig_site["f_in_h"], $user_data["f_t"], $user_data["last_sbor"]);
			$db->Query("UPDATE db_users_b SET 
			a_b = a_b + '$tomat_s', 
			b_b = b_b + '$straw_s', 
			c_b = c_b + '$pump_s', 
			d_b = d_b + '$peas_s', 
			e_b = e_b + '$pean_s', 
			f_b = f_b + '$snow_s', 
			all_time_a = all_time_a + '$tomat_s',
			all_time_b = all_time_b + '$straw_s',
			all_time_c = all_time_c + '$pump_s',
			all_time_d = all_time_d + '$peas_s',
			all_time_e = all_time_e + '$pean_s',
			all_time_f = all_time_f + '$snow_s',
			last_sbor = '".time()."' 
			WHERE id = '$usid' LIMIT 1");
			
			echo "<center><font color = 'green'><b>�� ������� Cryply!</b></font></center><BR />";
			
			$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
			$user_data = $db->FetchArray();
			
		}else echo "<center><font color = 'red'><b>Cryply ����� �������� �� ���� 1-�� ���� �� 10 �����!</b></font></center><BR />";
	
	}



?>
<?PHP
# �������
if(isset($_POST["sell"])){

$all_items = $user_data["a_b"] + $user_data["b_b"] + $user_data["c_b"] + $user_data["d_b"] + $user_data["e_b"] + $user_data["f_b"];

	if($all_items > 0){
	
		$money_add = $func->SellItems($all_items, $sonfig_site["items_per_coin"]);
		
		$tomat_b = $user_data["a_b"];
		$straw_b = $user_data["b_b"];
		$pump_b = $user_data["c_b"];
		$pean_b = $user_data["d_b"];
		$peas_b = $user_data["e_b"];
		$snow_b = $user_data["f_b"];
		
		$money_b = ( (100 - $sonfig_site["percent_sell"]) / 100) * $money_add;
		$money_p = ( ($sonfig_site["percent_sell"]) / 100) * $money_add;
		
		# ��������� ������
		$db->Query("UPDATE db_users_b SET money_b = money_b + '$money_b', money_p = money_p + '$money_p', a_b = 0, b_b = 0, c_b = 0, d_b = 0, e_b = 0, f_b = 0  
		WHERE id = '$usid'");
		
		$da = time();
		$dd = $da + 60*60*24*15;
		
		# ��������� ������ � ����������
		$db->Query("INSERT INTO db_sell_items (user, user_id, a_s, b_s, c_s, d_s, e_s, f_s, amount, all_sell, date_add, date_del) VALUES 
		('$usname','$usid','$tomat_b','$straw_b','$pump_b','$pean_b','$peas_b','$snow_b','$money_add','$all_items','$da','$dd')");
		
		echo "<center><font color = 'green'><b>�� ������� {$all_items} , �� ����� {$money_add} �����!</b></font></center><BR />";
		
		$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
		$user_data = $db->FetchArray();
		
	}else echo "<center><font color = 'red'><b>��� ������ ��������� :(</b></font></center><BR />";

}
?>  
</center>

<center><div class="silver-bk"><font color="black"> ��������! ������������ ���������� ����� � �������� 200CRP, ���� �� ������� CRP ������� ������ �����������</font>
<br>
<br>

<div class="col-md-2">
	<img src="/images/10.png" alt="">
	<div class="info">
		<?=$user_data["a_t"]; ?>	</div>
</div>
<div class="col-md-2">
	<img src="/images/11.png" alt="">
	<div class="info">
		<?=$user_data["b_t"]; ?>	</div>
</div>
<div class="col-md-2">
	<img src="/images/12.png" alt="">
	<div class="info">
		<?=$user_data["c_t"]; ?>	</div>
</div>
<div class="col-md-2">
	<img src="/images/13.png" alt="">
	<div class="info">
		<?=$user_data["d_t"]; ?>	</div>
</div>
<div class="col-md-2">
	<img src="/images/14.png" alt="">
	<div class="info">
		<?=$user_data["e_t"]; ?>	</div>
</div>

<div class="clr"></div>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tbody><tr>
    <td colspan="5" align="center" style="padding:5px;"><b>������ Cryply CRP</b></td>
    </tr>
  <tr>
    <td align="center" width="20%"><div class="sm-line-nt"><img src="/images/flat.png"></div></td>
    <td align="center" width="20%"><div class="sm-line-nt"><img src="/images/flat.png"></div></td>
	<td align="center" width="20%"><div class="sm-line-nt"><img src="/images/flat.png"></div></td>
    <td align="center" width="20%"><div class="sm-line-nt"><img src="/images/flat.png"></div></td>
    <td align="center" width="20%"><div class="sm-line-nt"><img src="/images/flat.png"></div></td>

    
  </tr>
  <tr>
    <td align="center"><?=$func->SumCalc($sonfig_site["a_in_h"], $user_data["a_t"], $user_data["last_sbor"]);?></td>
    <td align="center"><?=$func->SumCalc($sonfig_site["b_in_h"], $user_data["b_t"], $user_data["last_sbor"]);?></td>
    <td align="center"><?=$func->SumCalc($sonfig_site["c_in_h"], $user_data["c_t"], $user_data["last_sbor"]);?></td>
    <td align="center"><?=$func->SumCalc($sonfig_site["d_in_h"], $user_data["d_t"], $user_data["last_sbor"]);?></td>
    <td align="center"><?=$func->SumCalc($sonfig_site["e_in_h"], $user_data["e_t"], $user_data["last_sbor"]);?></td>
  </tr>
</tbody></table>

<div class="clr"></div>

<form action="" method="post">
<input type="submit" name="sbor" class="button login" value="������� CRP � Mining Pool">
<center><input type="submit" class="button login"  name="sell" value="������� �� <?php $all_items = $user_data["a_b"] + $user_data["b_b"] + $user_data["c_b"] + $user_data["d_b"] + $user_data["e_b"] + $user_data["f_b"]; echo $all_items/100 ?> �����" style="width: 50%;"class="bat" >
</center>
</form>			</div>
<div class="clr"></div>	
	</div>