

         <?PHP include("inc/_user_menu.php"); ?> 
<style>
.headerbar .top ul li a {
    font-size: 15px;
    color: #ffffff;
    font-weight: 700;
    padding: 5px 18px;
    border-radius: 1e3px;
    text-transform: uppercase;
}
.headerbar .top {
    /* height: 156px; */
    /* background: url(../images/top.png) no-repeat center top; */
    height: 100px;
    background: rgba(0,0,0,.5);
color: #fff;} 
.headerbar {
    height: 101px;
    background: url(../images/headers.png) no-repeat center top;
    position: relative;
    z-index: 99;
}
.footer-1 {
    padding: 40px 0;
    color: 00;
    background: #d8d1d585;
    margin-top: 979px;
}
.col-md-7 {
    display: inline-block;
    vertical-align: top;
    color: #fff;
    padding: 10px;
    width: 61%;
    margin-left: 538px;
}
.button:hover {
    color: #fff;
    text-transform: uppercase;
    background: #83b945;
    padding: 8px 12px;
    margin: 10px auto;
    display: table;
}</style>

<?PHP
$_OPTIMIZATION["title"] = "������� - ���������� �������";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

/*
if($_SESSION["user_id"] != 1){
echo "<center><b><font color = red>����������� ������</font></b></center>";
return;
}
*/
?>
<div class="col-md-7">
						


			
<h3>���������� �������</h3>

<h4>��� ������ ���������� +10%</h4>

<center><font color="black"><p style="font-size: 17px;font-weight: bold;">�������� ��������� �������</p></center>

<center><p style="font-size: 17px;font-weight: bold;color: red;">��������� ������������, ����� ��� ��� ��������� ������, ����������� �������� ���� �����.</p></center>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="menuinsert" style="width: 42%;   margin-left: 27%; margin-right: 2%;">
<table border="0" width="100%" cellspacing="5" cellpadding="5">
	<tbody>
	
	<tr>
		<td align="center" style="height: 75px;">
		<img border="0" src="/img/logo2.png" style="width: 200px;margin-top: -10px;    max-width: 90%;"></td>
	</tr>
	
	<tr>
	<td align="center">
	<div style="display: block;width: 100%;position: relative;margin: 0px auto 0px auto;height: 1px;background: rgb(141, 204, 255);border-radius: 1px;box-shadow: 0px 0px 2px 0px black;"></div>
	</td>
	</tr>

	<tr>
	<td align="center">
	<div class="ssilkanainseti">
	<a href="/account/insert">����������</a>
	</div>
	</td>
	</tr>
	
	</tr>
</tbody></table>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="menuinsert" style="width: 42%;   margin-left: 27%; margin-right: 2%;">
<table border="0" width="100%" cellspacing="5" cellpadding="5">
	<tbody>
	
	<tr>
		<td align="center" style="height: 75px;">
		<img border="0" src="/img/logo3.png" style="width: 200px;margin-top: -10px;    max-width: 90%;"></td>
	</tr>
	
	<tr>
	<td align="center">
	<div style="display: block;width: 100%;position: relative;margin: 0px auto 0px auto;height: 1px;background: rgb(141, 204, 255);border-radius: 1px;box-shadow: 0px 0px 2px 0px black;"></div>
	</td>
	</tr>

	<tr>
	<td align="center">
	<div class="ssilkanainseti">
	<a href="/account/qiwi_insert">����������</a>
	</div>
	</td>
	</tr>
	
	</tr>
</tbody></table>
</div>
	<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="menuinsert" style="width: 42%;   margin-left: 27%; margin-right: 2%;">
<table border="0" width="100%" cellspacing="5" cellpadding="5">
	<tbody>
	
	<tr>
		<td align="center" style="height: 75px;">
		<img border="0" src="/img/logo1.png" style="width: 200px;margin-top: -10px;    max-width: 90%;"></td>
	</tr>
	
	<tr>
	<td align="center">
	<div style="display: block;width: 100%;position: relative;margin: 0px auto 0px auto;height: 1px;background: rgb(141, 204, 255);border-radius: 1px;box-shadow: 0px 0px 2px 0px black;"></div>
	</td>
	</tr>

	<tr>
	<td align="center">
	<div class="ssilkanainseti">
	<a href="/account/insertfk">����������</a>
	</div>
	</td>
	</tr>
	
	</tr>
</tbody></table>
</div>
</tbody></table></center></font>

    </form>

<div id="error3"></div>

<script type="text/javascript">
calculate(100);
</script></font> </center>
<br></p>
<br>
<br>
<script type="text/javascript">
var min = 0.01;
var ser_pr = 100;
function calculate(st_q) {
    
	var sum_insert = parseFloat(st_q);
	$('#res_sum').html( (sum_insert * ser_pr).toFixed(0) );
	
	
}
	
</script>


    <input type="hidden" name="m" value="">
<p> </p>
<div class="inp2">
</div>
 <font color="black">  <center>
<style>
.menuinsert {
border: 1px solid #70A71A;
    box-shadow: 1px 1px 3px 0px #0A0A0A;
    background: #f9ffef;
}

.menuinsertssd {
border: 1px solid #70A71A;
    box-shadow: 1px 1px 3px 0px #0A0A0A;
    background: #D2F3BF;
}

.cur_list img {
width: 65px;
}

.devis {
border: 1px solid #7EA0BB;
box-shadow: 1px 1px 3px 0px black;
padding: 3px 0px 0px 0px;
background: #A5BBD1;
}

.ssilkanainseti a {
display: block;
text-decoration: none;
background: #575d53;
text-align: center;
margin: 5px 0px 0px 0px;
padding: 10px 2px 10px 2px;
border-radius: 2px;
color: rgb(255, 255, 255);
-webkit-transition: background 0.3s ease-in;
transition: background 0.3s ease-in;
-moz-transition: background 0.3s ease-in;
-o-transition: background 0.3s ease-in;
font-size: 14pt;
font-weight: bolder;
}

.ssilkanainseti a:hover {
transition: background 0.3s ease-in;
background: #C3F89E;
color: #56B017;
}
</style>





<center>
<center>

<br>

</center>
<br><br>

<div class="clr"></div>		
</div>

			</div>