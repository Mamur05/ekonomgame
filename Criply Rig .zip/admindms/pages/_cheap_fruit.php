     <div class="mainbody">
	<?PHP include("inc/_admin_menu.php"); ?> 
        
<div id="statblock">



         
  <div class="thecontent">

                    <!-- Контантная часть -->
<?PHP
##################################################################
#  ####    #####   #          #   #####   ###     ####   #    #  #
#  #   #   #       #          #   #       #  #    #   #  #    #  #
#  ####    #####   #          #   #####   ###     ####   #    #  #
#  #           #    #   ##   #    #       #  #    # #    #    #  #
#  #       #####      #    #      #####   ###  #  #  #    ####   #
#                                                                #
#  PSWeb.ru                                                      #
#  E-mail: i@psweb.ru ICQ 610 855 981                            #
##################################################################
$i=1;
$db->Query("SELECT * FROM cheap_fruit");
while($data_c = $db->FetchArray())
{
	$cheap_amount[$i] = $data_c['amount'];
	$cheap_cost[$i]=$data_c['cost'];
	$i++;
}

# Обновление
if(isset($_POST["save"])){
	
	$cheap_amount1 = intval($_POST["cheap_amount1"]);
	$cheap_amount2 = intval($_POST["cheap_amount2"]);
	$cheap_amount3 = intval($_POST["cheap_amount3"]);
	$cheap_amount4 = intval($_POST["cheap_amount4"]);
	$cheap_amount5 = intval($_POST["cheap_amount5"]);
	
	$cheap_cost1 = intval($_POST["cheap_cost1"]);
	$cheap_cost2 = intval($_POST["cheap_cost2"]);
	$cheap_cost3 = intval($_POST["cheap_cost3"]);
	$cheap_cost4 = intval($_POST["cheap_cost4"]);
	$cheap_cost5 = intval($_POST["cheap_cost5"]);

	# Проверка на ошибки
	$errors = true;
	
	if($cheap_amount1 < 0 OR $cheap_amount1 > 999){
		$errors = false; echo "<center><font color = 'red'><b>Количество первых дешевых птиц должно быть от 0 до 999 шт</b></font></center><BR />"; 
	}
	
	if($cheap_amount2 < 0 OR $cheap_amount2 > 999){
		$errors = false; echo "<center><font color = 'red'><b>Количество вторых дешевых птиц должно быть от 0 до 999 шт</b></font></center><BR />"; 
	}
	
	if($cheap_amount3 < 0 OR $cheap_amount3 > 999){
		$errors = false; echo "<center><font color = 'red'><b>Количество третьих дешевых птиц должно быть от 0 до 999 шт</b></font></center><BR />"; 
	}
	
	if($cheap_amount4 < 0 OR $cheap_amount4 > 999){
		$errors = false; echo "<center><font color = 'red'><b>Количество четвертых дешевых птиц должно быть от 0 до 999 шт</b></font></center><BR />"; 
	}
	
	if($cheap_amount5 < 0 OR $cheap_amount5 > 999){
		$errors = false; echo "<center><font color = 'red'><b>Количество пятых дешевых птиц должно быть от 0 до 999 шт</b></font></center><BR />"; 
	}
	
	if($cheap_cost1 < 0){
		$errors = false; echo "<center><font color = 'red'><b>Стоимость не может быть меньше 0</b></font></center><BR />"; 
	}
	
	if($cheap_cost2 < 0){
		$errors = false; echo "<center><font color = 'red'><b>Стоимость не может быть меньше 0</b></font></center><BR />"; 
	}
	
	if($cheap_cost3 < 0){
		$errors = false; echo "<center><font color = 'red'><b>Стоимость не может быть меньше 0</b></font></center><BR />"; 
	}
	
	if($cheap_cost4 < 0){
		$errors = false; echo "<center><font color = 'red'><b>Стоимость не может быть меньше 0</b></font></center><BR />"; 
	}
	
	if($cheap_cost5 < 0){
		$errors = false; echo "<center><font color = 'red'><b>Стоимость не может быть меньше 0</b></font></center><BR />"; 
	}
	
	# Обновление
	if($errors){
	
		$db->Query("UPDATE cheap_fruit SET 
		
		amount = '$cheap_amount1',
		cost = '$cheap_cost1'
		WHERE id = '1'");
		
		$db->Query("UPDATE cheap_fruit SET 
		
		amount = '$cheap_amount2',
		cost = '$cheap_cost2'
		WHERE id = '2'");
		
		$db->Query("UPDATE cheap_fruit SET 
		
		amount = '$cheap_amount3',
		cost = '$cheap_cost3'
		WHERE id = '3'");
		
		$db->Query("UPDATE cheap_fruit SET 
		
		amount = '$cheap_amount4',
		cost = '$cheap_cost4'
		WHERE id = '4'");
		
		$db->Query("UPDATE cheap_fruit SET 
		
		amount = '$cheap_amount5',
		cost = '$cheap_cost5'
		WHERE id = '5'");
		
		echo "<center><font color = 'green'><b>Сохранено</b></font></center><BR />";
		$i=1;
		$db->Query("SELECT * FROM cheap_fruit");
		while($data_c = $db->FetchArray())
		{
			$cheap_amount[$i] = $data_c['amount'];
			$cheap_cost[$i]=$data_c['cost'];
			$i++;
		}
	}

}

?>
<form action="" method="post">
<table width="100%" border="0">
<tr bgcolor="#efefef">
			<td align="center" class="m-tb">Название</td>
			<td align="center" class="m-tb">Количество</td>
			<td align="center" class="m-tb">Стоимость</td>
		  </tr>
  <tr bgcolor="#EFEFEF">
    <td><b>Первый:</b></td>
	<td width="20" align="center"><input type="text" name="cheap_amount1" value="<?=$cheap_amount['1']; ?>" /></td>
	<td width="20" align="center"><input type="text" name="cheap_cost1" value="<?=$cheap_cost['1']; ?>" /></td>
  </tr>
  <tr bgcolor="#EFEFEF">
    <td><b>Второй:</b></td>
	<td width="20" align="center"><input type="text" name="cheap_amount2" value="<?=$cheap_amount['2']; ?>" /></td>
	<td width="20" align="center"><input type="text" name="cheap_cost2" value="<?=$cheap_cost['2']; ?>" /></td>
  </tr>
  <tr bgcolor="#EFEFEF">
    <td><b>Третий:</b></td>
	<td width="20" align="center"><input type="text" name="cheap_amount3" value="<?=$cheap_amount['3']; ?>" /></td>
	<td width="20" align="center"><input type="text" name="cheap_cost3" value="<?=$cheap_cost['3']; ?>" /></td>
  </tr>
  <tr bgcolor="#EFEFEF">
    <td><b>Четвертый:</b></td>
	<td width="20" align="center"><input type="text" name="cheap_amount4" value="<?=$cheap_amount['4']; ?>" /></td>
	<td width="20" align="center"><input type="text" name="cheap_cost4" value="<?=$cheap_cost['4']; ?>" /></td>
  </tr>
  <tr bgcolor="#EFEFEF">
    <td><b>Пятый:</b></td>
	<td width="20" align="center"><input type="text" name="cheap_amount5" value="<?=$cheap_amount['5']; ?>" /></td>
	<td width="20" align="center"><input type="text" name="cheap_cost5" value="<?=$cheap_cost['5']; ?>" /></td>
  </tr>
  <tr> <td colspan="3" align="center"><input type="submit" name="save" value="Сохранить" /></td> </tr>
</table>
</form>
</div>
</div></div>
 