<div class="s-bk-lf">
	<div class="acc-title">Пополения QIWI</div>
</div>
<div class="silver-bk"><div class="clr"></div>	
<BR />
<?PHP

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

# Выплачено
if(isset($_POST["payment"])){

$ret_id = intval($_POST["payment"]);
$db->Query("SELECT * FROM db_qiwi_insert WHERE id = '{$ret_id}'");

	if($db->NumRows() == 1){
	
	$ret_data = $db->FetchArray();


	
	$user_id = $ret_data["user_id"];
	$sum = $ret_data["sum"];
	$sump = $ret_data["sum"] * $sonfig_site["ser_per_wmr"];
	
	
	
	
		# Настройка рефа
	$db->Query("SELECT user, referer_id FROM db_users_a WHERE id = '{$user_id}' LIMIT 1");$user_ardata = $db->FetchArray();
	$user_name = $user_ardata["user"];
	$refid = $user_ardata["referer_id"];
	 $sump = $sump + ($sump * 0.0);
		 $to_referer = ($sump * 0.20);
		# зачисляем юзеру
		$db->Query("UPDATE db_users_b SET money_b = money_b +'$sump', to_referer = to_referer + '$to_referer', insert_sum = insert_sum + '$sum' WHERE id = '$user_id'");
		
		# зачисляем рефу
		$db->Query("UPDATE db_users_b SET money_b = money_b + $to_referer, from_referals = from_referals + '$to_referer' WHERE id = '$refid'");
		
	# Статистика пополнений
   $da = time();
   $dd = $da + 60*60*24*15;
   $sums = 'Qiwi';
   $db->Query("INSERT INTO db_insert_money (user, user_id, money, serebro, date_add, date_del) 
   VALUES ('$user_name','$user_id','$sum','$sums','$da','$dd')");



# Конкурс
$competition = new competition($db);
$competition->UpdatePoints($user_id, $sum);
#--------


# Обновление статистики сайта
	$db->Query("UPDATE db_stats SET all_insert = all_insert + '$sum' WHERE id = '1'");
		
		$db->Query("DELETE FROM db_qiwi_insert WHERE id = '$ret_id'");
	
		echo "<center><b>Зачислено, статистика обновлена</b></center><BR />";
		
	}else echo "<center><b>Заявка не найдена :(</b></center><BR />";

}

# Отказ в пополнении
if(isset($_POST["return"])){

$ret_id = intval($_POST["return"]);
$db->Query("SELECT * FROM db_qiwi_insert WHERE id = '{$ret_id}'");

	if($db->NumRows() == 1){
	
	$ret_data = $db->FetchArray();
	
	$user_id = $ret_data["user_id"];
	$sum = $ret_data["sum"];
		
		$db->Query("DELETE FROM db_qiwi_insert WHERE id = '$ret_id'");
		
		echo "<center><b>Заявка на пополнение отклонена</b></center><BR />";
		
	}else echo "<center><b>Заявка не найдена :(</b></center><BR />";

}




$db->Query("SELECT * FROM db_qiwi_insert");
$ast = $db->NumRows();
if($ast > 0){

?>
<table cellpadding='3' cellspacing='0' border='0' bordercolor='#336633' align='center' width="99%">
  <tr bgcolor="#efefef">
    <td align="center" class="m-tb">Пользователь</td>
    <td align="center" class="m-tb">Сумма</td>
	<td align="center" class="m-tb">№ Платежа</td>
	<td align="center" class="m-tb">Отказать</td>
	<td align="center" class="m-tb">Зачислить</td>
  </tr>

<?PHP

	while($data = $db->FetchArray()){
	
	?>
	<tr class="htt">
	<td align="center"><?=$data["user"]; ?></td>
    <td align="center"><?=$data["sum"]; ?></td>
	<td align="center"><input type="text" value="<?=$data["vaycher"]; ?>" /></td>
  	<td align="center">
	
		<form action="" method="post">
			<input type="hidden" name="return" value="<?=$data["id"]; ?>" />
			<input type="submit" value="Отказать" />
		</form>
	
	</td>
	<td align="center">
	
		<form action="" method="post">
			<input type="hidden" name="payment" value="<?=$data["id"]; ?>" />
			<input type="submit" value="Зачислить" />
		</form>
	
	</td>
	</tr>
	<?PHP
	
	}

?>

</table>
<?PHP

}else echo "<center><b>Нет заявок на пополнение через Qiwi</b></center><BR />";

?>
</div>
<div class="clr"></div>
