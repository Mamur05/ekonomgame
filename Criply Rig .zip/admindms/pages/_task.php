<div class="col-md-8">	
<div class="s-bk-lf">
									<div class="title">Статистика проекта</div>
								</div>
								<div class="silver-bk">	
<table cellpadding='3' cellspacing='0' border='0' bordercolor='#FFC737' align='center' width="99%">
<tr>
<td align="center" class="m-tb"><a style='color:black;' href="/index.php?menu=adm0shik&sel=task&sort=1">Задания на модерации</a> || 
<td align="center" class="m-tb"><a style='color:black;' href="/index.php?menu=adm0shik&sel=task&sort=2">Все задания</a> || 
<td align="center" class="m-tb"><a style='color:black;' href="/index.php?menu=adm0shik&sel=task&cat_add=1">Добавить категорию заданий</a></td> 

</tr>
</table>
<?
if(isset($_GET['cat_add'])) {
if(isset($_GET['del_cat'])){
$dell = intval($_GET['del_cat']);
$db->Query("DELETE FROM db_task_cat WHERE id = '$dell'");
}
if(isset($_POST['name'])) {
$name = $db->RealEscape($_POST['name']);
$db->Query("INSERT INTO db_task_cat (`name`) VALUES ('$name')");
}
?>
<form method="post" action="">
<input type="text" name="name" value="Название категории">
<input type="submit" value="Отправить">
</form>
<?

$db->Query("SELECT * FROM db_task_cat ORDER BY id DESC");
while($ct = $db->FetchArray()) {
echo $ct['name'].' - <a href="/index.php?menu=adm0shik&sel=task&cat_add=1&del_cat='.$ct['id'].'">Удалить</a><br>';
}
return;
}
?>


<?
if(isset($_GET['id_task'])) {

if(isset($_POST['id_t'])) {
$id_t = intval($_POST['id_t']);
$db->Query("DELETE FROM db_task WHERE id = '$id_t'");
echo 'Задание удалено!';
}

if(isset($_POST['id_tok'])) {
$id_t = intval($_POST['id_tok']);
$db->Query("UPDATE db_task SET moder = '1' WHERE id = '$id_t'");
echo "Задание одобрено!";
}
$id_task = intval($_GET['id_task']);
$db->Query("SELECT * FROM db_task WHERE id = '$id_task'");
$ts = $db->FetchArray();
?>
<table align="center" width="550" border="1">

<div id="response"></div>
<tr>
<td width="50px">
<b>ID Задания:</b></td><td> <?=$ts['id']; ?></td></tr>



<tr>
<td width="50px"><b>Стоимость выполнения:</b></td> <td><?=$ts['cena']; ?> Серебра</td></tr>
<tr>
<td width="50px"><b>Категория:</b></td> <td> <?=$ts['name_cat']; ?></td></tr>

<tr>
<td width="50px"><b>Название задания: </b></td> <td><?=$ts['text_k']; ?></td>
</tr>

<tr>
<td width="50px"><b>Текст задания: </b></td> <td><?=$ts['text']; ?></td>
</tr>

<tr>
<td width="50px"><b>Ссылка на сайт URL: </b></td> <td><a href="<?=$ts['url']; ?>" target="_blank"><?=$ts['url']; ?></a> (настоятельно рекомендуем проверять с включеным антивирусом)</td>
</tr>

<tr>
<td width="50px"><b>Что нужно указать для проверки:</b></td> <td> <?=$ts['otvet']; ?></td>
</tr>

<tr><td colspan="2">
<form method="post" action="">
<input type="hidden" name="id_t" value="<?=$ts['id']; ?>">
<input type="submit" value="Удалить">
</form>
</td></tr>
<?
if($ts['moder'] == 0) {
?>
<tr><td colspan="2">
<form method="post" action="">
<input type="hidden" name="id_tok" value="<?=$ts['id']; ?>">
<input type="submit" value="Одобрить">
</form>
</td></tr>
<? } ?>
</table>
<?
return;
}
?>




<table align="center" width="550" border="1">
<tr align="center"  bgcolor="#019FDA">
<td>ID</td>

<td>Категория / Краткое описание</td>
<td>Стоимость</td>
<td>Действие</td>
</tr>
<?
if(isset($_GET['sort'])) {
$sort = intval($_GET['sort']);
if($sort == 1) {$ss = "WHERE moder = '0'"; } elseif($sort == 2) { $ss = ''; }
}
$db->Query("SELECT * FROM db_task $ss ORDER BY id DESC");
while($task = $db->FetchArray()) {

?>
<tr align="center">
<td><?=$task['id']; ?></td>
<td><?=$task['name_cat']; ?> / <br>
<b><?=$task['text_k']; ?></b></td>
<td><?=$task['cena']; ?></td>
<td><a href="/index.php?menu=adm0shik&sel=task&id_task=<?=$task['id']; ?>">Подробнее</a></td>
</tr>
<? } ?>
</table>

</div> </div>
<div class="clr"></div>	