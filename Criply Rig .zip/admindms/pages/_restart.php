<?PHP

?>
<div class="s-bk-lf">
	<div class="acc-title3">Рекламная Статистика </div>
</div>
<div class="silver-bk"><div class="clr"></div>	
									
<link href="/style/style-admin.css" rel="stylesheet" type="text/css" />
Если вы хотите сделать рестарт проекта нажмите кнопку ниже, будет начислено каждому пользователю по 1000 серебра на покупки!
<BR />
<BR />

<style>
.bankrot-but {
    height: 40px;
    width: 200px;
    border: white solid;
    background: #E35D45;
    color: rgb(255, 255, 255);
    text-shadow: rgb(155, 5, 5) 0 2px 5px;
	}
</style>
<?PHP
$usid = $_SESSION["user_id"];
$refid = $_SESSION["referer_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

$hide_form = false;

# рестарт
if(isset($_POST["bankrotme"])){

echo "<center><font color = 'green'><b>Вы действительно хотите сделать рестарт?</b></font></center><BR />";
echo "<center><font color = 'red'><b>ВНИМАНИЕ! Каждому пользователю будет начислено по 1000 серебра на покупки, и анулирована статистика! </b></font></center><BR />";

echo 
"<center><form action='' method='post'>
<input class='bankrot-but' name='bankrotmeyes' type='submit' value='Подтвердить'>
</form></center>";
echo "<center><font color = 'red'><b>Подтвердите для продолжения.</b></font></center><BR />";

$hide_form = true;

}else echo "<center><font color = 'red'><b>Для подтверждения рестарта нажмите кнопку!</b></font></center><BR />";

if(!$hide_form){
?>

<center>
<form action="" method="post">
<input class="bankrot-but" name="bankrotme" type="submit" value="Сделать рестарт">
</form></center>

<?
}
# подтверждение действий
if(isset($_POST["bankrotmeyes"])){

# Нуллим записи
$db->Query("UPDATE db_users_b SET money_b = '5000', money_p = '0', a_t = '0', b_t = '0', c_t = '0', d_t = '0', e_t = '0', a_b = '0', b_b = '0', c_b = '0', d_b = '0', e_b = '0', insert_sum = '0', payment_sum = '0', from_referals = '0', all_time_a = '0', all_time_b = '0', all_time_c = '0', all_time_d = '0', all_time_e = '0', last_sbor = '0', to_referer = '0'");
//$db->Query("UPDATE db_users_a SET referals = '0'");
echo "<center><font color = 'green'><b>Рестарт произведен!</b></font></center><BR />";
}
?>
</div>