     <div class="mainbody">
	<?PHP include("inc/_admin_menu.php"); ?> 
        
<div id="statblock">



         
  <div class="thecontent">

                    <!-- Контантная часть -->
<?PHP

	if(isset($_POST["tx"])){
	
		$fid = fopen("cache/pages/index.txt", "w+");
		fwrite($fid, $_POST["tx"]);
		fclose($fid);
		
	}

?>

<form action="" method="post">
<textarea name="tx" cols="78" rows="25"><?=@file_get_contents("cache/pages/index.txt"); ?></textarea>
<BR /><BR />
<center><input type="submit" value="—охранить" /></center>
</form>
</div>
</div></div>
 