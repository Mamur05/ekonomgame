<BR />

<?PHP if(!isset($_GET["menu"]) OR $_GET["menu"] != "Location: /".$admFolder.""){ ?>

<?PHP } ?>


<div class="clr"></div>
</div>
 
 
<center>
<table> 
<td>
<div style="width:468px;height:60px;border: 3px solid #f95c5c;">
<div id="linkslot_157791"><script src="https://linkslot.ru/bancode.php?id=157791" async></script></div>
</div>
</td>
<td width="5px"></td>
<td>
<div style="width:468px;height:60px;border: 3px solid #f95c5c;">
<div id="linkslot_157792"><script src="https://linkslot.ru/bancode.php?id=157792" async></script></div>
</div>
</td>
</table>
</center>
  

<div class="footer">
<div style="padding: 5px 0 0 0;">
<center>
<br><br>
<span style="margin: 0 20px 0 0;"><a class="footer_a" href="/contacts">КОНТАКТЫ</a></span>
<span style="margin: 0 20px 0 0;"><a class="footer_a" href="https://payeer.com/04354435">РЕГИСТРАЦИЯ В PAYEER</a></span>

</center>
</div>
   
<div style="color:#000; font-weight: bold; font-size: 15px;">
<center>
<p>COPYRIGHT © 2017. ALL RIGHTS RESERVED. </p>
</center>
</div>
<div class="clr-line"></div>
</div>



<div class="clr-line"></div>
</div>
</div>

<a href="#" class="gotop" title="Наверх" style="display: inline;"> 
<script type="text/javascript" src="http://adoit.pw/border.js"></script></a>  
<style>.gotop {  
position: fixed;  
width: 85px;  
height: 65px;  
right: 20px;  
bottom: 5px;  
display: block;  
background: url('http://pnghosts.ru/img/gotop.png') no-repeat;  
z-index: 9998;  
display: none;opacity: 0.5;  
}  
.gotop:hover {opacity: 1.0;}</style>
</body>
</html>

