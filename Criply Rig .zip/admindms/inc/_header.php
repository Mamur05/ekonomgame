﻿<html>
	<head>
		<title>AdminPanel</title>
		
<!-- saved from url=(0027)h/ -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
		<title>Админка</title>
		
		<meta name="description" content="FUTURE-CITY-BIZ.RU - это интересный и увлекательный игровой симулятор, который позволит Вам зарабатывать деньги в интернете! ">
		<meta name="keywords" content="Заработок в интернете">
		<link href="/admindms/index_files/stylefc.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="/admindms/index_files/jquery.js"></script>
		<script type="text/javascript" src="/admindms/index_files/functions.js"></script>
<script type="text/javascript" src="/admindms/index_files/openapi.js"></script>
	

	</head>
 
<body cz-shortcut-listen="true">

			<div class="wrap">
			
				<div class="header">
 
					<div class="clr"></div><center><img src="/admindms/index_files/log.png"><p>


</p><p>
<table>
<tbody><tr>

<td><div class="menu-top"><a href="/">Главная</a></div></td>

<td><div class="menu-top"><a href="/rules">Правила</a></div></td>
<td><div class="menu-top"><a href="/about">О проекте</a></div></td>
<td><div class="menu-top"><a href="/contacts">Контакты</a></div></td>
 
</tr>
</tbody></table> 
 
</p></center>
 
<div class="s-bk-lf">
	
</div>
  
<?PHP include("inc/_menu_left.php"); ?>
 
							<div class="clr"></div>	
							</div>
 
				</div>

			<center><div class="s-bk-lf">
 
			</div>
 
</center></div>
 