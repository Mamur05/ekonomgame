<?PHP

if(isset($_SESSION["admin"])){

	if(isset($_SESSION["admin"])){
	
		include("_admin_menu.php");
	
	}
	
}


include("inc/_stats.php");
?>