 
<div class="clr"></div>

	
						<div class="content">
							<div class="cl-left">


	</div>
							<div class="cl-right">
								
 
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1251"><script type="text/javascript">
 
$(function() {
$('#dropdown_nav li').find('.sub_nav').hide();
$('#dropdown_nav li').hover(function() {
$(this).find('.sub_nav').fadeIn(400);
 }, function() {
$(this).find('.sub_nav').fadeOut(100);
 });
 });
 
</script></head>
<!-- Начало #dropdown_nav -->

 <ul id="dropdown_nav">
 
 

 
          <li><a href="index.php?menu=stats">Статистика</a></li>
			 <li><a href="index.php?menu=users">Пользователи</a></li>
			  <li><a href="index.php?menu=payments">Список выплат</a></li>
			  
            <li><a href="index.php?menu=story_insert">Пополнения</a></li>
			
			 <li><a href="index.php?menu=config">Настройки</a></li>

 
 <li><!--<a href="index.php?menu=cheap_fruit">Дешевые птицы</a></li>-->



 <li><a href="index.php?menu=story_buy">История покупок</a></li>
 <li><a href="index.php?menu=story_swap">История обменов</a></li>



<li><a href="index.php?menu=restart">рестарт</a></li>

	
 <li>	<a href="/account/exit">Выход из профиля</a></li>
 </ul>


</li>
 

 </li>
 </ul>

 <!-- конец #dropdown_nav -->
  
<div class="clr"></div>

	
						<div class="content">
							<div class="cl-left">


	</div>
							<div class="cl-right">
                                                                <div class="s-bk-lf">
									
								</div>
	</div>
 