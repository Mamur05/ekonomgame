$(document).ready(function(){
 $(".spincrement").spincrement();
});